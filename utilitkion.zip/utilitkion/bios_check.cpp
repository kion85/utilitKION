// bios_check.cpp
#include <fstream>
#include <iostream>

int main() {
    std::ifstream bios_vendor("/sys/class/dmi/id/bios_vendor");
    std::ifstream bios_version("/sys/class/dmi/id/bios_version");
    
    std::cout << "BIOS Vendor: " << bios_vendor.rdbuf() << "\n";
    std::cout << "BIOS Version: " << bios_version.rdbuf() << "\n";
    
    return 0;
}