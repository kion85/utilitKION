// ssl_check.cpp
#include <iostream>

int main() {
    system("openssl version");
    return 0;
}