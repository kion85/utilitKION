// cpu_temp.cpp
#include <fstream>
#include <iostream>

int main() {
    std::ifstream temp_file("/sys/class/thermal/thermal_zone0/temp");
    int temp;
    temp_file >> temp;
    std::cout << "CPU Temp: " << temp/1000 << "°C\n";
    return 0;
}