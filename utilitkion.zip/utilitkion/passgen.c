// passgen.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    srand(time(0));
    const char chars[] = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%^&*";
    for (int i = 0; i < 12; i++) {
        putchar(chars[rand() % sizeof(chars)]);
    }
    return 0;
}