// system_analyzer.cpp
#include <iostream>
#include <fstream>

int main() {
    std::ifstream uptime_file("/proc/uptime");
    std::string uptime;
    uptime_file >> uptime;
    std::cout << "Uptime: " << uptime << " sec\n";
    return 0;
}