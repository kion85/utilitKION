// backup_tool.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

int main() {
    system("mkdir -p /backup");
    system("cp -r --preserve=all /home/user/docs /backup/");
    printf("Backup completed!\n");
    return 0;
}