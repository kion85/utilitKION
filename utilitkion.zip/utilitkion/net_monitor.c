// net_monitor.c
#include <stdio.h>
#include <stdlib.h>  // Добавлен для system()

int main() {
    printf("Network monitoring started...\n");
    
    // Выполняем ping и проверяем потерю пакетов
    int result = system("ping -c 10 8.8.8.8 | grep 'packet loss'");
    
    if (result == -1) {
        perror("Error executing ping command");
        return 1;
    }
    
    return 0;
}
