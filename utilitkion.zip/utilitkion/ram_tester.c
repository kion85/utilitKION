// ram_tester.c
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define SIZE 100 * 1024 * 1024 // 100 MB

int main() {
    char *mem = malloc(SIZE);
    memset(mem, 0xAA, SIZE);
    printf("RAM test passed!\n");
    free(mem);
    return 0;
}