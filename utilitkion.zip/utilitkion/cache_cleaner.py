# cache_cleaner.py
import os

def clear_cache():
    os.system("sync; echo 3 > /proc/sys/vm/drop_caches")
    print("Cache cleared!")

if __name__ == "__main__":
    clear_cache()