// disk_health.cpp
#include <iostream>

int main() {
    system("smartctl -H /dev/sda | grep 'SMART overall-health'");
    return 0;
}